clear all; close all;
load_Surfaces;    % importing *.igs surface geometries for hydrostat. computation

%% Set Maneuvers
%most items in this part can be 

Usp          = 10*-0.51444;   %target speed in m/s

m_switch     = 1; %0: SP, 1: VZZ, 2: HZZ 3:Turning Circle 4:max-q
%for switch 1~4, use fixed value dX_imposed for related sail or stern planes.
%1,4: pid for dV is ignored. dH is acting on stern planes
%2,3: pid for dH is ignored. dZ is acting on sail and stern planes

n_switch     = 0; %1: speed is controlled. otherwise use fixed rps using n_imposed
sail_switch  = 0; %if 0, sail plane is fixed to neutral position
LCG_switch   = 0; %if 1, trim tank is active
mass_switch  = 1; %if 1, ballast tank is active

dX_imposed   =  20; %imposed control surface def. in degs for m_swtich 1,2,3,4
n_imposed    = 1.2; %fixed rps when n_switch not equal to 0;
check_angle  =  10; %checking angle for VZZ and HZZ. ignored when m_switch is not 1 or 2

target_z     =-4.0-11.3724; %target depth for maneuver. CG is -11.3724 below sailtop;
target_y     = 0;
target_pitch = 0;
target_yaw   = 0;

%% Initial Values
Bx_0 = [0 0 target_z 0 0 0]; %initial displcement
Bv_0 = [Usp 0 0 0 0 0];      %initial velocity
Ba_0 = [0 0 0 0 0 0];        %iniial acc.
n_0  = 1.18;                 %initial propeller rps

%% Simulation Parameter
fwrite    = 0; %if 1, exportes geometry in *.stl
its       = 1;      %time between each geometry export in sec. active only when frwite=1

Seastate  = 5; %Seastate value between 0 and 6
DoF_switch= [1 1 1 1 1 1];  %availability for Degrees of freedom in HDM

%% Kinematic Properties
Bb   = 4418825.3321; %mass of submarine in kg
Mb   = 4418825.3321; %buoyancy of submarine. usually identicall to Mb

Ixx  = 5.23e7;       %mass moment of inertial about x-axis. in kg*m^2
Iyy  = 1.375e9;      %mass moment of inertial about y-axis. in kg*m^2
Izz  = 1.367e9;      %mass moment of inertial about z-axis. in kg*m^2
Ixy  = 0;
Ixz  = 0;
Iyz  = 0;

Xb   = 0;            %longi.distance between  CB and pivot point. Put to 0 if not defined explicitly
Yb   = 0;
Zb   = 0.4406;       %restoring moment arm:distance between CG and CB
Xg   = 0;            %longi. distance between CG and pivot point. put to 0 if not defined explicitly
Yg   = 0;
Zg   = 0;            %longi. distance between CG and pivot point. put to 0 if not defined explicitly