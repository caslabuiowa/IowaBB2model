function [ntri,vert1,vert2,vert3,dA,normal] = import_stl(filename,L0,Xcg)
%Reading STL information
f = fopen(filename,'r');
c = textscan(f,'%s','delimiter','\n');
fclose(f);
c = c{:};
[~,~,~,z] = regexp(c,'-*\d+\.\d+(E-*\d+)*\d+(e-*\d+)*');
z1 = z(~cellfun(@isempty,z));
raw = str2double(reshape([z1{:}],3,[])');

%Assigning variable Space.
ndat=length(raw);
ntri=round(ndat/4);

normal=zeros(ntri,3);
vert1=zeros(ntri,3);
vert2=zeros(ntri,3);
vert3=zeros(ntri,3);
dA=zeros(ntri,1);

%Loading vertices and normal vectors
%Compute position vectors of triangles with respect to CG
for i=1:ndat
    arg1=i-1; int1=round(arg1/4)+1;
    arg2=i-2; int2=round(arg2/4)+1;
    arg3=i-3; int3=round(arg3/4)+1;
    int4=round(i/4);
    
    if rem(arg1,4)==0
        normal(int1,1)=raw(i,1);
        normal(int1,2)=raw(i,2);
        normal(int1,3)=raw(i,3);
    elseif rem(arg2,4)==0
        vert1(int2,1)=raw(i,1).*L0-Xcg(1);
        vert1(int2,2)=raw(i,2).*L0-Xcg(2);
        vert1(int2,3)=raw(i,3).*L0-Xcg(3);
    elseif rem(arg3,4)==0
        vert2(int3,1)=raw(i,1).*L0-Xcg(1);
        vert2(int3,2)=raw(i,2).*L0-Xcg(2);
        vert2(int3,3)=raw(i,3).*L0-Xcg(3);
    else
        vert3(int4,1)=raw(i,1)*L0-Xcg(1);
        vert3(int4,2)=raw(i,2)*L0-Xcg(2);
        vert3(int4,3)=raw(i,3)*L0-Xcg(3);
    end
 
    for i=1:ntri
        A=[vert2(i,1)-vert1(i,1); vert2(i,2)-vert1(i,2); vert2(i,3)-vert1(i,3);];
        B=[vert3(i,1)-vert1(i,1); vert3(i,2)-vert1(i,2); vert3(i,3)-vert1(i,3);];
        n=cross(A,B)/norm(cross(A,B));
        dA(i,1)=0.5*norm(cross(A,B));
%        normal(i,1)=n(1); normal(i,2)=n(2); normal(i,3)=n(3);
    end
end
