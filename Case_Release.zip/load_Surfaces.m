L0=1;
Xcg=[0; 0; 0;];

L0=70.2;
Xcg=[32.3114*1.0005364451; 0; 0;];
%1.0005364451 for N x dP
%*0.99999
[nt_Hull,vt1_Hull,vt2_Hull,vt3_Hull,dA_Hull,n_Hull] = import_stl('surface/Hull.stl',L0,Xcg);
[nt_Sail,vt1_Sail,vt2_Sail,vt3_Sail,dA_Sail,n_Sail] = import_stl('./surface/Sail.stl',L0,Xcg);
[nt_PH,vt1_PH,vt2_PH,vt3_PH,dA_PH,n_PH] = import_stl('./surface/PropHub.stl',L0,Xcg);
%[nt_Sail1,vt1_Sail1,vt2_Sail1,vt3_Sail1,dA_Sail1,n_Sail1] = import_stl('./surface/SailStar.stl',L0,Xcg);
%[nt_Sail2,vt1_Sail2,vt2_Sail2,vt3_Sail2,dA_Sail2,n_Sail2] = import_stl('./surface/SailStar-mirrored.stl',L0,Xcg);
%[nt_Sail3,vt1_Sail3,vt2_Sail3,vt3_Sail3,dA_Sail3,n_Sail3] = import_stl('./surface/SailBottom.stl',L0,Xcg);
%[nt_BP1,vt1_BP1,vt2_BP1,vt3_BP1,dA_BP1,n_BP1] = import_stl('./surface/SailPlanes1.stl',L0,Xcg);
%[nt_BP2,vt1_BP2,vt2_BP2,vt3_BP2,dA_BP2,n_BP2] = import_stl('./surface/SailPlanes1-mirrored.stl',L0,Xcg);
[nt_SProot,vt1_SProot,vt2_SProot,vt3_SProot,dA_SProot,n_SProot] = import_stl('./surface/TailPlaneRoots.stl',L0,Xcg);
[nt_BP1,vt1_BP1,vt2_BP1,vt3_BP1,dA_BP1,n_BP1] = import_stl('./surface/SailPlanes1.stl',L0,Xcg);
[nt_BP2,vt1_BP2,vt2_BP2,vt3_BP2,dA_BP2,n_BP2] = import_stl('./surface/SailPlanes1-mirrored.stl',L0,Xcg);
[nt_X1a,vt1_X1a,vt2_X1a,vt3_X1a,dA_X1a,n_X1a] = import_stl('./surface/TailPlaneLowerSt1.stl',L0,Xcg);
[nt_X1b,vt1_X1b,vt2_X1b,vt3_X1b,dA_X1b,n_X1b] = import_stl('./surface/TailPlaneLowerSt2.stl',L0,Xcg);
[nt_X2a,vt1_X2a,vt2_X2a,vt3_X2a,dA_X2a,n_X2a] = import_stl('./surface/TailPlaneUpperSt1-mirrored.stl',L0,Xcg);
[nt_X2b,vt1_X2b,vt2_X2b,vt3_X2b,dA_X2b,n_X2b] = import_stl('./surface/TailPlaneUpperSt2-mirrored.stl',L0,Xcg);
[nt_X3a,vt1_X3a,vt2_X3a,vt3_X3a,dA_X3a,n_X3a] = import_stl('./surface/TailPlaneUpperPt1.stl',L0,Xcg);
[nt_X3b,vt1_X3b,vt2_X3b,vt3_X3b,dA_X3b,n_X3b] = import_stl('./surface/TailPlaneUpperPt2.stl',L0,Xcg);
[nt_X4a,vt1_X4a,vt2_X4a,vt3_X4a,dA_X4a,n_X4a] = import_stl('./surface/TailPlaneLowerPt1.stl',L0,Xcg);
[nt_X4b,vt1_X4b,vt2_X4b,vt3_X4b,dA_X4b,n_X4b] = import_stl('./surface/TailPlaneLowerPt2.stl',L0,Xcg);
%{
[nt_BP1,vt1_BP1,vt2_BP1,vt3_BP1,dA_BP1,n_BP1] = import_stl('./surface/SailPlanes1.stl',L0,Xcg);
[nt_BP2,vt1_BP2,vt2_BP2,vt3_BP2,dA_BP2,n_BP2] = import_stl('./surface/SailPlanes1-mirrored.stl',L0,Xcg);
[nt_X1a,vt1_X1a,vt2_X1a,vt3_X1a,dA_X1a,n_X1a] = import_stl('./surface/TailPlaneLowerSt1.stl',L0,Xcg);
[nt_X1b,vt1_X1b,vt2_X1b,vt3_X1b,dA_X1b,n_X1b] = import_stl('./surface/TailPlaneLowerSt2.stl',L0,Xcg);
[nt_X2a,vt1_X2a,vt2_X2a,vt3_X2a,dA_X2a,n_X2a] = import_stl('./surface/TailPlaneUpperSt1-mirrored.stl',L0,Xcg);
[nt_X2b,vt1_X2b,vt2_X2b,vt3_X2b,dA_X2b,n_X2b] = import_stl('./surface/TailPlaneUpperSt2-mirrored.stl',L0,Xcg);
[nt_X3a,vt1_X3a,vt2_X3a,vt3_X3a,dA_X3a,n_X3a] = import_stl('./surface/TailPlaneUpperPt1.stl',L0,Xcg);
[nt_X3b,vt1_X3b,vt2_X3b,vt3_X3b,dA_X3b,n_X3b] = import_stl('./surface/TailPlaneUpperPt2.stl',L0,Xcg);
[nt_X4a,vt1_X4a,vt2_X4a,vt3_X4a,dA_X4a,n_X4a] = import_stl('./surface/TailPlaneLowerPt1.stl',L0,Xcg);
[nt_X4b,vt1_X4b,vt2_X4b,vt3_X4b,dA_X4b,n_X4b] = import_stl('./surface/TailPlaneLowerPt2.stl',L0,Xcg);
%}